---
title: Continuous Integration
permalink: /docs/continuous-integration/
---

Continuous Integration (CI) enables you to publish your Jekyll generated website with confidence by automating the quality assurance and deployment processes. You can quickly get started using CI with one of the providers below:

* [Travis CI](travis-ci)
* [CircleCI](circleci)
* [Buddy](buddyworks)
