# frozen_string_literal: true

module Jekyll
  VERSION = "3.9.0".freeze
end
